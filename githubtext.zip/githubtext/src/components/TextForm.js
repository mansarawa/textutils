import React,{useState} from 'react'
import './Textform.css'
export default function TextForm(props) {
    const [text,setText]=useState("");
    const handleupclick=()=>{
        
        let newText=text.toUpperCase();
        setText(newText)
        props.showAlert("Converted To uppercase","success");
    }
    const handleclearclick=()=>{
        
        let newText='';
        setText(newText)
        props.showAlert("Text was Removed","success");
    }
    const handleloclick=()=>{
        
        let newText=text.toLowerCase();
        setText(newText)
        props.showAlert("Converted To lowercase","success");
    }
    const handleonchange=(event)=>{
       
        setText(event.target.value)
    }
    const handlecopyclick=()=>{
        var mytext=document.getElementById('myBox')
        mytext.select();
        navigator.clipboard.writeText(mytext.value)
        props.showAlert("Text was copied","success");
    }
    
    const handleextraclick=()=>{
        let newText=text.split(/[ ]+/)
        setText(newText.join(" "));
        props.showAlert("Extra spaces was deleted","success");
    }
    return (
        <>
        <div className='container'>
            
                <h1>{props.heading}</h1>
                <div className="mb-3">
                    
                    <textarea
                        className="form-control"
                        id="myBox"
                        value={text}
                        onChange={handleonchange}
                        rows={10}
                        defaultValue={""}
                        style={{backgroundColor:props.mode === '#042743'?'light':'light'}}
                    />
                </div>
            
            <button className="btn btn-primary mx-2" onClick={handleupclick}>Convert to UpperCase</button>
            <button className="btn btn-primary mx-2" onClick={handleloclick}>Convert to LowerCase</button>
            <button className="btn btn-primary mx-2" onClick={handleextraclick}>Remove Extra Space</button>
            <button className="btn btn-primary mx-2" onClick={handlecopyclick}>Copy Text</button>
    
            <button className="btn btn-danger mx-3" onClick={handleclearclick}>Clear Text</button>
            
            
        </div>
        <div className="container my-3">
            <h1>Your Text Summary</h1>
            <p>{text.split(" ").length} Words and {text.length} Chatacters</p>
            <p>{ 0.008*text.split(" ").length} Minets Read</p>
        </div>
        </>
    )
}

